package bd.edu.bubt.regup;

/*Registration verification activity.
  Check if the user is a valid student of BUBT
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegVerificationActivity extends AppCompatActivity {

    private EditText var_id, ser_num;
    private Button next;

    private String ID, S_num, get_serial;
    //IP address of the pc containing the php file
    String server_url = "http://192.168.31.234/data.php";

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_verification);

        var_id = (EditText) findViewById(R.id.v_id);
        ser_num = (EditText) findViewById(R.id.ser_num);
        next = (Button) findViewById(R.id.next);

        progressDialog = new ProgressDialog(this);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ID = var_id.getText().toString().trim();
                S_num = ser_num.getText().toString().trim();

                if(TextUtils.isEmpty(ID)){

                    Toast.makeText(getApplicationContext(),"Enter your ID.",Toast.LENGTH_SHORT).show();
                    return;
                }

                else if(TextUtils.isEmpty(S_num)){

                    Toast.makeText(getApplicationContext(),"Enter your ID card serial number.",Toast.LENGTH_SHORT).show();
                    return;
                }

                else if(TextUtils.isEmpty(ID) && TextUtils.isEmpty(S_num)){

                    Toast.makeText(getApplicationContext(),"Enter your ID and ID card serial number.",Toast.LENGTH_SHORT).show();
                    return;
                }

                progressDialog.setMessage("Please wait..");
                progressDialog.show();

                /*using volley library function to send a request to the
                  php file with the users ID number.
                 */
                StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        /*
                           Using try-catch block to handle stringIndexOutOfBound exception.
                            For invalid ID and Serial Number php file returns a null string.
                            This string generates stringIndexOutOfBound exception.
                         */
                        try{

                            if(!response.isEmpty())
                            {
                                //filtering the serial number from the string
                                get_serial = response;
                                int a = get_serial.lastIndexOf('"');
                                get_serial = get_serial.substring(0,a);
                                a = get_serial.lastIndexOf('"');
                                get_serial = get_serial.substring(a+1,get_serial.length());

                                //checking if serial number matches the input
                                if(TextUtils.equals(get_serial, S_num)) {
                                    progressDialog.dismiss();
                                    Toast.makeText(getApplicationContext(), "Verification Complete!", Toast.LENGTH_SHORT).show();

                                    //send ID to RegistrationActivity


                                    Intent intent = new Intent(RegVerificationActivity.this, RegistrationActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                                //if serial number does not match
                                else
                                {
                                    progressDialog.dismiss();
                                    Toast.makeText(getApplicationContext(), "Invalid Serial Number!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Invalid ID/Serial Number! Try again!",Toast.LENGTH_SHORT).show();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(),"Invalid ID/Serial Number! Try again!",Toast.LENGTH_SHORT).show();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("ID",ID);
                        return params;
                    }
                };


                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);

            }
        });
    }

    public void onBackPressed(){
        //send to LoginActivity
        this.finish();
    }
}
