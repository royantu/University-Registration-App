package bd.edu.bubt.regup;

//login activity

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.SignInMethodQueryResult;

public class LoginActivity extends AppCompatActivity {

    private EditText email, pass;
    private Button login;
    private TextView forgot_pass, registration;

    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;

    private String mail;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = (EditText) findViewById(R.id.email);
        pass = (EditText) findViewById(R.id.password);
        forgot_pass = (TextView) findViewById(R.id.forgot_pass);
        registration = (TextView) findViewById(R.id.registration);
        login = (Button) findViewById(R.id.login);

        progressDialog = new ProgressDialog(this);
        firebaseAuth = FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mail = email.getText().toString().trim();
                password = pass.getText().toString().trim();

                if(TextUtils.isEmpty(mail)){

                    Toast.makeText(getApplicationContext(),"Enter your Email.",Toast.LENGTH_SHORT).show();
                    return;
                }

                else if(TextUtils.isEmpty(password)){

                    Toast.makeText(getApplicationContext(),"Enter your password.",Toast.LENGTH_SHORT).show();
                    return;
                }

                else if(TextUtils.isEmpty(mail) && TextUtils.isEmpty(password)){

                    Toast.makeText(getApplicationContext(),"Enter your Email & password.",Toast.LENGTH_SHORT).show();
                    return;
                }

                progressDialog.setMessage("Please wait..");
                progressDialog.show();

                //login process
                firebaseAuth.fetchSignInMethodsForEmail(mail)
                        .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                            @Override
                            public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                                //checking if mail is valid
                                boolean check = !task.getResult().getSignInMethods().isEmpty();

                                //if mail is valid
                                if(check){
                                    firebaseAuth.signInWithEmailAndPassword(mail, password)
                                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                                @Override
                                                public void onComplete(@NonNull Task<AuthResult> task) {

                                                    //if sign in is successful, user is sent to the corresponding activity
                                                    if(task.isSuccessful()){

                                                        progressDialog.dismiss();
                                                        Toast.makeText(getApplicationContext(),"Login successful!",Toast.LENGTH_LONG).show();

                                                        //admin login
                                                        if(TextUtils.equals(mail,"regup.bubt@gmail.com"))
                                                        {
                                                            Intent intent = new Intent(LoginActivity.this,AdminActivity.class);
                                                            startActivity(intent);
                                                            finish();
                                                        }

                                                        //fetch user data to check if the user is a student or faculty



                                                        //student login



                                                        //faculty login
                                                    }

                                                    //if sign in is unsuccessful, user is notified
                                                    else{

                                                        progressDialog.dismiss();
                                                        Toast.makeText(getApplicationContext(),"Could not login! Please try again.",Toast.LENGTH_LONG).show();
                                                    }
                                                }
                                            });
                                }

                                //if mail is not valid or wrong mail
                                else{
                                    progressDialog.dismiss();
                                    Toast.makeText(getApplicationContext(),"Could not login! User not found.",Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });


        forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to password recovery activity
            }
        });

        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //user is sent to the registration activity
                Intent intent = new Intent(LoginActivity.this, RegVerificationActivity.class);
                startActivity(intent);
            }
        });
    }


    public void onBackPressed(){
        //closing the application
        this.finish();
    }
}
