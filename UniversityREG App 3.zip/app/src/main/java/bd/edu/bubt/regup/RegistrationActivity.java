package bd.edu.bubt.regup;

//Registration activity. User puts required information for registration.

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class RegistrationActivity extends AppCompatActivity {

    private static final String TAG = null;
    private Spinner sp1, sp2, sp3;
    private Button next;

    LinkedList<String> deptlist = new LinkedList<>();
    LinkedList<String> intlist = new LinkedList<>();
    LinkedList<String> seclist = new LinkedList<>();

    //String[] deptarr;
    String[] intkarr;
    String[] secrr;

    private FirebaseFirestore firestore;
    //private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        firestore = FirebaseFirestore.getInstance();
        //databaseReference = FirebaseDatabase.getInstance().getReference().child("Intake-Sec");

        sp1 = (Spinner) findViewById(R.id.spinner_dept);
        sp2 = (Spinner) findViewById(R.id.spinner_int);
        sp3 = (Spinner) findViewById(R.id.spinner_sec);
        next = (Button) findViewById(R.id.next);

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference().child("Intake-Sec");
        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                List<String> eventList = new ArrayList<String>();
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String key = ds.getKey();
                    eventList.add(key);
                    Log.d(TAG, key);
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, eventList);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sp1.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        };
        rootRef.addListenerForSingleValueEvent(valueEventListener);


        /*ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    deptlist.add(ds.getKey());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        };
        databaseReference.addListenerForSingleValueEvent(valueEventListener);

        Toast.makeText(getApplicationContext(),""+deptlist,Toast.LENGTH_LONG).show();*/

        /*firestore.collection("dept_int_sec").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                if(task.isSuccessful())
                {
                    for (DocumentSnapshot document : task.getResult()) {
                        deptlist.add(document.getId());
                    }
                }
            }
        });

        String[] deptarr = deptlist.toArray(new String[deptlist.size()]);
        Toast.makeText(getApplicationContext(),""+deptarr.length,Toast.LENGTH_LONG).show();

        ArrayAdapter ar = new ArrayAdapter(this, android.R.layout.simple_spinner_item,deptarr);
        ar.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        sp1.setAdapter(ar);*/


    }
}
