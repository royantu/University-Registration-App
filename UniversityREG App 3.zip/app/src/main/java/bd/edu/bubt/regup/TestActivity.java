package bd.edu.bubt.regup;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class TestActivity extends AppCompatActivity {

    Spinner sp;
    String[] table = {"1", "2", "3", "4", "5"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        sp = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter a = new ArrayAdapter(this, android.R.layout.simple_spinner_item,table);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        sp.setAdapter(a);
    }
}
